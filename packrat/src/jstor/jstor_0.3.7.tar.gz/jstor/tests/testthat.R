library(testthat)
library(jstor)

test_check("jstor")
